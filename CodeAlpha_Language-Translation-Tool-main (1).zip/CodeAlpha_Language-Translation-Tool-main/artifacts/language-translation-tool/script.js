import { selectReliableTranslation } from './translation-validation.js';

const languages = [
  { code: 'en', label: 'English' },
  { code: 'es', label: 'Spanish' },
  { code: 'fr', label: 'French' },
  { code: 'de', label: 'German' },
  { code: 'it', label: 'Italian' },
  { code: 'pt', label: 'Portuguese' },
  { code: 'ja', label: 'Japanese' },
  { code: 'ko', label: 'Korean' },
  { code: 'zh-CN', label: 'Chinese (Simplified)' },
  { code: 'ar', label: 'Arabic' },
  { code: 'hi', label: 'Hindi' },
  { code: 'te', label: 'Telugu' },
  { code: 'ta', label: 'Tamil' },
  { code: 'kn', label: 'Kannada' },
  { code: 'ml', label: 'Malayalam' },
  { code: 'bn', label: 'Bengali' },
  { code: 'mr', label: 'Marathi' },
  { code: 'nl', label: 'Dutch' },
  { code: 'ru', label: 'Russian' },
];

const icons = {
  arrowRight: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 12h15"></path><path d="m13 6 6 6-6 6"></path></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="8" y="8" width="11" height="11" rx="2"></rect><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"></path></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m5 12 4 4L19 6"></path></svg>',
  swap: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 7h11l-3-3"></path><path d="m18 7-3 3"></path><path d="M17 17H6l3 3"></path><path d="m6 17 3-3"></path></svg>',
};

const root = document.querySelector('#root');

if (!root) {
  throw new Error('Translation tool root was not found.');
}

root.innerHTML = `
  <div class="app-shell">
    <header class="topbar">
      <a class="brand" href="/" data-testid="link-brand" aria-label="Lingo home">
        <span class="brand-mark" aria-hidden="true"><span>l</span></span>
        <span class="brand-name">lingo<span class="brand-note"> / utility 01</span></span>
      </a>
      <div class="topbar-note"><span class="status-dot" aria-hidden="true"></span> ready in your browser</div>
    </header>

    <main class="main-grid">
      <section class="intro-panel" aria-labelledby="intro-title">
        <div class="eyebrow" aria-hidden="true"></div>
        <div class="intro-copy">
          <h1 id="intro-title">Say it in a <em>new</em> language.</h1>
          <p>A clear place to find the right words. Write naturally, choose your pair, and let the meaning travel.</p>
        </div>
        <div class="intro-foot">
          <p>Thoughtful translation for everyday phrases.</p>
          <span class="orbit-mark" aria-hidden="true">01</span>
        </div>
      </section>

      <section class="workspace" aria-labelledby="workspace-title">
        <div class="workspace-heading">
          <div>
            <span class="eyebrow">Translate a phrase</span>
            <h2 id="workspace-title">Start with your words.</h2>
            <p>Keep it short and natural for the most useful result.</p>
          </div>
          <span class="demo-label">MyMemory API</span>
        </div>

        <form class="translation-form" id="translation-form" novalidate>
          <div class="language-row">
            <div>
              <label class="field-label" for="source-language">From</label>
              <div class="select-wrap">
                <select class="language-select" id="source-language" data-testid="select-source-language" aria-label="Source language"></select>
              </div>
            </div>
            <button class="swap-button" id="swap-languages" type="button" data-testid="button-swap-languages" aria-label="Swap languages">${icons.swap}</button>
            <div>
              <label class="field-label" for="target-language">To</label>
              <div class="select-wrap">
                <select class="language-select" id="target-language" data-testid="select-target-language" aria-label="Target language"></select>
              </div>
            </div>
          </div>

          <label class="field-label" for="source-text">Your phrase</label>
          <div class="text-card">
            <textarea class="source-text" id="source-text" data-testid="input-source-text" maxlength="500" placeholder="Write something worth saying..." aria-describedby="character-count"></textarea>
            <span class="char-count" id="character-count" data-testid="text-character-count">0 / 500</span>
          </div>

          <div class="translate-row">
            <div class="hint"><span class="hint-mark" aria-hidden="true">i</span><span>Translation happens securely in this tab.</span></div>
            <button class="translate-button" id="translate-button" type="submit" data-testid="button-translate">${icons.arrowRight}<span>Translate phrase</span></button>
          </div>
        </form>

        <section class="output-section" aria-labelledby="output-label">
          <span class="section-label" id="output-label">Your translation</span>
          <div class="output-card" id="output-card" aria-live="polite">
            <div class="output-placeholder" id="output-placeholder">
              <span class="placeholder-symbol" aria-hidden="true">→</span>
              <p>Your translated phrase will appear here.</p>
            </div>
          </div>
          <div class="status-line" id="status-line" data-testid="status-message" role="status"></div>
        </section>

        <div class="tip-strip">
          <span class="tip-number">TIP 01</span>
          <p><strong>Context helps.</strong> Add a little more than one word when a phrase could mean different things.</p>
        </div>
      </section>
    </main>
  </div>
`;

const form = document.querySelector('#translation-form');
const sourceLanguage = document.querySelector('#source-language');
const targetLanguage = document.querySelector('#target-language');
const sourceText = document.querySelector('#source-text');
const characterCount = document.querySelector('#character-count');
const swapLanguages = document.querySelector('#swap-languages');
const translateButton = document.querySelector('#translate-button');
const outputCard = document.querySelector('#output-card');
const statusLine = document.querySelector('#status-line');

const languageOptions = languages
  .map((language) => `<option value="${language.code}">${language.label}</option>`)
  .join('');

sourceLanguage.innerHTML = languageOptions;
targetLanguage.innerHTML = languageOptions;
sourceLanguage.value = 'en';
targetLanguage.value = 'es';

let latestTranslation = '';
let copyResetTimer;
const MAX_INPUT_LENGTH = 500;
const MAX_TRANSLATION_LENGTH = 5000;
const REQUEST_TIMEOUT_MS = 12000;
const REQUEST_COOLDOWN_MS = 1200;
const SESSION_CHARACTER_BUDGET = 5000;
const SESSION_REQUEST_BUDGET = 20;
const SESSION_USAGE_KEY = 'lingo-translation-usage';
const MAX_CACHE_ENTRIES = 20;
const supportedLanguageCodes = new Set(languages.map((language) => language.code));
const translationCache = new Map();
let activeRequestKey = '';
let lastRequestStartedAt = 0;
let sessionUsage = loadSessionUsage();

function loadSessionUsage() {
  try {
    const stored = JSON.parse(window.sessionStorage.getItem(SESSION_USAGE_KEY) || '{}');
    const characters = Number(stored?.characters);
    const requests = Number(stored?.requests);

    if (Number.isInteger(characters) && characters >= 0 && Number.isInteger(requests) && requests >= 0) {
      return { characters, requests };
    }
  } catch {
    // Private browsing and restricted storage should not block translation.
  }

  return { characters: 0, requests: 0 };
}

function saveSessionUsage() {
  try {
    window.sessionStorage.setItem(SESSION_USAGE_KEY, JSON.stringify(sessionUsage));
  } catch {
    // Translation still works when session storage is unavailable.
  }
}

function getRequestKey(text, sourceCode, targetCode) {
  return JSON.stringify([sourceCode, targetCode, text]);
}

function cacheTranslation(requestKey, translatedText) {
  if (translationCache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = translationCache.keys().next().value;
    translationCache.delete(oldestKey);
  }

  translationCache.set(requestKey, translatedText);
}

function createTranslationError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

function getTranslationErrorCopy(error) {
  switch (error?.code) {
    case 'rate-limit':
      return {
        title: 'Too many requests.',
        message: error.message || 'Please wait and try again later.',
        status: 'The translation service rate limit was reached.',
      };
    case 'quota':
      return {
        title: 'Translation limit reached.',
        message: 'The translation service has reached its usage limit.',
        status: 'The translation service usage limit was reached.',
      };
    case 'timeout':
      return {
        title: 'The translation took too long.',
        message: 'Check your connection and try again in a moment.',
        status: 'The translation request timed out.',
      };
    case 'service':
      return {
        title: 'The translation service is busy.',
        message: 'Please wait a moment and try again.',
        status: 'The translation service is temporarily unavailable.',
      };
    case 'invalid-response':
      return {
        title: 'We could not use that result.',
        message: 'The translation service returned an unexpected response.',
        status: 'The translation service returned an invalid result.',
      };
    case 'uncertain':
      return {
        title: 'This result needs context.',
        message: 'The service could not provide a reliable translation for this input. Add a short phrase with context and try again.',
        status: 'Add context so the intended meaning is clear.',
      };
    default:
      return {
        title: 'We could not translate that.',
        message: 'Check your connection and try again in a moment.',
        status: 'The translation service is unavailable right now.',
      };
  }
}

function languageName(code) {
  return languages.find((language) => language.code === code)?.label || code;
}

function setStatus(message = '', type = '') {
  statusLine.textContent = message;
  statusLine.className = `status-line${type ? ` ${type}` : ''}`;
}

function setOutputPlaceholder() {
  outputCard.className = 'output-card';
  outputCard.innerHTML = `
    <div class="output-placeholder" id="output-placeholder">
      <span class="placeholder-symbol" aria-hidden="true">→</span>
      <p>Your translated phrase will appear here.</p>
    </div>
  `;
  latestTranslation = '';
}

function setMessage(title, message, type = 'error') {
  const icon = type === 'success' ? icons.check : '!';
  outputCard.className = `output-card is-${type === 'success' ? 'ready' : 'error'}`;
  outputCard.innerHTML = `
    <div class="output-message">
      <span class="message-icon" aria-hidden="true">${icon}</span>
      <strong>${title}</strong>
      <p>${message}</p>
    </div>
  `;
  latestTranslation = '';
}

function setLoading() {
  outputCard.className = 'output-card is-loading';
  outputCard.innerHTML = `
    <div class="loading-content" aria-label="Translating">
      <span class="skeleton-line"></span>
      <span class="skeleton-line"></span>
      <span class="skeleton-line"></span>
    </div>
  `;
}

function setTranslatedText(text, targetCode) {
  latestTranslation = text;
  outputCard.className = 'output-card is-ready';
  outputCard.innerHTML = `
    <div class="translated-content" data-testid="text-translated-output">${escapeHtml(text)}</div>
    <div class="output-meta">
      <span class="output-language">${escapeHtml(languageName(targetCode))}</span>
      <button class="copy-button" id="copy-translation" type="button" data-testid="button-copy-translation">${icons.copy}<span>Copy</span></button>
    </div>
  `;
  document.querySelector('#copy-translation')?.addEventListener('click', copyTranslation);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function updateCharacterCount() {
  characterCount.textContent = `${sourceText.value.length} / ${MAX_INPUT_LENGTH}`;
}

function setLoadingState(isLoading) {
  translateButton.disabled = isLoading;
  translateButton.querySelector('span').textContent = isLoading ? 'Translating...' : 'Translate phrase';
}

async function requestTranslation() {
  const text = sourceText.value.trim();
  if (!text) {
    setOutputPlaceholder();
    setStatus('Write a phrase before translating.', 'error');
    sourceText.focus();
    return;
  }

  if (text.length > MAX_INPUT_LENGTH) {
    setStatus(`Keep your phrase to ${MAX_INPUT_LENGTH} characters or fewer.`, 'error');
    sourceText.focus();
    return;
  }

  const sourceCode = sourceLanguage.value;
  const targetCode = targetLanguage.value;

  if (!supportedLanguageCodes.has(sourceCode) || !supportedLanguageCodes.has(targetCode)) {
    setMessage('Choose a supported language.', 'Please select a language from each list.');
    setStatus('The selected language pair is not supported.', 'error');
    return;
  }

  const requestKey = getRequestKey(text, sourceCode, targetCode);

  if (activeRequestKey) {
    setStatus('A translation is already in progress.', 'error');
    return;
  }

  if (sourceCode === targetCode) {
    setTranslatedText(text, targetCode);
    setStatus('Both languages match, so your original phrase is shown.', 'success');
    return;
  }

  if (translationCache.has(requestKey)) {
    const cachedTranslation = translationCache.get(requestKey);
    const cachedResult = typeof cachedTranslation === 'string'
      ? { text: cachedTranslation, warning: '' }
      : cachedTranslation;
    setTranslatedText(cachedResult.text, targetCode);
    setStatus(
      cachedResult.warning || 'Translation ready to use.',
      cachedResult.warning ? 'warning' : 'success',
    );
    return;
  }

  const now = Date.now();
  if (now - lastRequestStartedAt < REQUEST_COOLDOWN_MS) {
    setStatus('Please wait a moment before translating again.', 'error');
    return;
  }

  if (
    sessionUsage.requests >= SESSION_REQUEST_BUDGET ||
    sessionUsage.characters + text.length > SESSION_CHARACTER_BUDGET
  ) {
    setMessage('Session translation limit reached.', 'Please wait before making more requests.');
    setStatus('The translation limit for this session has been reached.', 'error');
    return;
  }

  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    setMessage('You appear to be offline.', 'Reconnect to the internet and try again.');
    setStatus('There is no network connection.', 'error');
    return;
  }

  activeRequestKey = requestKey;
  lastRequestStartedAt = now;
  sessionUsage = {
    characters: sessionUsage.characters + text.length,
    requests: sessionUsage.requests + 1,
  };
  saveSessionUsage();
  setLoadingState(true);
  setLoading();
  setStatus('Finding the right words...', '');

  const query = new URLSearchParams({
    q: text,
    langpair: `${sourceCode}|${targetCode}`,
  });

  const controller = new AbortController();
  let didTimeout = false;
  const timeoutId = window.setTimeout(() => {
    didTimeout = true;
    controller.abort();
  }, REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(`https://api.mymemory.translated.net/get?${query.toString()}`, {
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });

    if (response.status === 429) {
      const retryAfter = Number(response.headers.get('Retry-After'));
      const waitMessage = Number.isFinite(retryAfter) && retryAfter > 0
        ? `Please wait ${retryAfter} seconds and try again.`
        : 'Please wait and try again later.';
      throw createTranslationError('rate-limit', waitMessage);
    }

    if (response.status === 408) {
      throw createTranslationError('timeout', 'Check your connection and try again in a moment.');
    }

    if (response.status >= 500) {
      throw createTranslationError('service', 'Please wait a moment and try again.');
    }

    if (!response.ok) {
      throw createTranslationError('service', 'Please wait a moment and try again.');
    }

    const result = await response.json();
    if (!result || typeof result !== 'object') {
      throw createTranslationError('invalid-response', 'The translation service returned an unexpected response.');
    }

    const responseStatus = Number(result.responseStatus);
    if (result.quotaFinished === true) {
      throw createTranslationError('quota', 'The translation service has reached its usage limit.');
    }

    if (!Number.isInteger(responseStatus)) {
      throw createTranslationError('invalid-response', 'The translation service returned an unexpected response.');
    }

    if (responseStatus < 200 || responseStatus >= 300) {
      if (responseStatus === 429) {
        throw createTranslationError('rate-limit', 'Please wait and try again later.');
      }
      throw createTranslationError('service', 'Please wait a moment and try again.');
    }

    const selectedTranslation = selectReliableTranslation(result, {
      inputText: text,
      sourceCode,
      targetCode,
      maxLength: MAX_TRANSLATION_LENGTH,
    });
    if (!selectedTranslation) {
      throw createTranslationError(
        'uncertain',
        'The service could not provide a reliable translation for this input.',
      );
    }

    cacheTranslation(requestKey, selectedTranslation);
    setTranslatedText(selectedTranslation.text, targetCode);
    setStatus(
      selectedTranslation.warning || 'Translation ready to use.',
      selectedTranslation.warning ? 'warning' : 'success',
    );
  } catch (error) {
    const normalizedError = didTimeout
      ? createTranslationError('timeout', 'Check your connection and try again in a moment.')
      : error;
    const errorCopy = getTranslationErrorCopy(normalizedError);
    setMessage(errorCopy.title, errorCopy.message);
    setStatus(errorCopy.status, 'error');
  } finally {
    window.clearTimeout(timeoutId);
    activeRequestKey = '';
    setLoadingState(false);
  }
}

async function copyTranslation() {
  if (!latestTranslation) return;

  try {
    await navigator.clipboard.writeText(latestTranslation);
  } catch {
    const fallback = document.createElement('textarea');
    fallback.value = latestTranslation;
    fallback.setAttribute('readonly', '');
    fallback.style.position = 'fixed';
    fallback.style.opacity = '0';
    document.body.appendChild(fallback);
    fallback.select();
    document.execCommand('copy');
    fallback.remove();
  }

  const copyButton = document.querySelector('#copy-translation');
  if (!copyButton) return;
  copyButton.classList.add('is-copied');
  copyButton.innerHTML = `${icons.check}<span>Copied</span>`;
  setStatus('Copied to your clipboard.', 'success');
  window.clearTimeout(copyResetTimer);
  copyResetTimer = window.setTimeout(() => {
    if (copyButton.isConnected) {
      copyButton.classList.remove('is-copied');
      copyButton.innerHTML = `${icons.copy}<span>Copy</span>`;
    }
  }, 2200);
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  requestTranslation();
});

sourceText.addEventListener('input', () => {
  updateCharacterCount();
  if (sourceText.value.trim()) {
    setStatus('');
  }
});

swapLanguages.addEventListener('click', () => {
  const currentSource = sourceLanguage.value;
  sourceLanguage.value = targetLanguage.value;
  targetLanguage.value = currentSource;
  setStatus(`Language pair changed to ${languageName(sourceLanguage.value)} and ${languageName(targetLanguage.value)}.`, '');
});