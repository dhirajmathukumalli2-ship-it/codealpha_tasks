import assert from 'node:assert/strict';
import test from 'node:test';

import {
  isTargetLanguageText,
  selectReliableTranslation,
} from './translation-validation.js';

const options = (inputText, sourceCode, targetCode) => ({
  inputText,
  sourceCode,
  targetCode,
});

test('keeps a valid English to Telugu response even when unrelated Latin matches exist', () => {
  const result = selectReliableTranslation(
    {
      responseData: { translatedText: 'హలో', match: 1 },
      matches: [
        { translation: 'హలో', segment: 'hello', match: 1, quality: 74 },
        { translation: 'bagunava', segment: 'hello', match: 0.99, quality: 100 },
      ],
    },
    options('hello', 'en', 'te'),
  );

  assert.equal(result.text, 'హలో');
  assert.equal(result.warning, '');
});

test('warns when a valid single-word translation has multiple meanings', () => {
  const result = selectReliableTranslation(
    {
      responseData: { translatedText: 'లైట్', match: 0.98 },
      matches: [
        { translation: 'లైట్', segment: 'light', match: 0.98, quality: 74 },
        { translation: 'కాంతి', segment: 'Light', match: 0.98, quality: 60 },
      ],
    },
    options('light', 'en', 'te'),
  );

  assert.equal(result.text, 'లైట్');
  assert.match(result.warning, /more than one meaning/);
});

test('uses a language-matched MyMemory candidate when responseData is in the source language', () => {
  const result = selectReliableTranslation(
    {
      responseData: { translatedText: 'నీరు', match: 1 },
      matches: [
        { translation: 'నీరు', segment: 'నీరు', match: 1, quality: 63 },
        { translation: 'Water', segment: 'నీరు', match: 0.99, quality: 74 },
      ],
    },
    options('నీరు', 'te', 'en'),
  );

  assert.equal(result.text, 'Water');
  assert.match(result.warning, /mixed language results/);
});

test('preserves a valid short phrase without adding a single-word warning', () => {
  const result = selectReliableTranslation(
    {
      responseData: {
        translatedText: 'I need help at the station',
        match: 0.85,
      },
      matches: [
        {
          translation: 'I need help at the station',
          segment: 'నాకు స్టేషన్‌లో సహాయం కావాలి',
          match: 0.85,
          quality: 70,
        },
      ],
    },
    options('నాకు స్టేషన్‌లో సహాయం కావాలి', 'te', 'en'),
  );

  assert.equal(result.text, 'I need help at the station');
  assert.equal(result.warning, '');
});

test('preserves valid same-spelling translations across related languages', () => {
  const result = selectReliableTranslation(
    {
      responseData: { translatedText: 'hotel', match: 1 },
      matches: [
        { translation: 'hotel', segment: 'hotel', match: 1, quality: 80 },
      ],
    },
    options('hotel', 'en', 'es'),
  );

  assert.equal(result.text, 'hotel');
});

test('rejects a response when MyMemory provides no target-language candidate', () => {
  const result = selectReliableTranslation(
    {
      responseData: { translatedText: 'unrelated', match: 1 },
      matches: [
        { translation: 'also unrelated', segment: 'word', match: 0.99, quality: 100 },
      ],
    },
    options('word', 'en', 'te'),
  );

  assert.equal(result, null);
});

test('recognizes the expected Telugu and English scripts', () => {
  assert.equal(isTargetLanguageText('తెలుగు', 'te'), true);
  assert.equal(isTargetLanguageText('Telugu', 'te'), false);
  assert.equal(isTargetLanguageText('Water', 'en'), true);
  assert.equal(isTargetLanguageText('నీరు', 'en'), false);
});