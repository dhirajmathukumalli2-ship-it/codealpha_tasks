const scriptPatterns = {
  Latin: /\p{Script=Latin}/u,
  Cyrillic: /\p{Script=Cyrillic}/u,
  Arabic: /\p{Script=Arabic}/u,
  Devanagari: /\p{Script=Devanagari}/u,
  Telugu: /\p{Script=Telugu}/u,
  Tamil: /\p{Script=Tamil}/u,
  Kannada: /\p{Script=Kannada}/u,
  Malayalam: /\p{Script=Malayalam}/u,
  Bengali: /\p{Script=Bengali}/u,
  Han: /\p{Script=Han}/u,
  Hiragana: /\p{Script=Hiragana}/u,
  Katakana: /\p{Script=Katakana}/u,
  Hangul: /\p{Script=Hangul}/u,
};

const targetScriptGroups = {
  en: ['Latin'],
  es: ['Latin'],
  fr: ['Latin'],
  de: ['Latin'],
  it: ['Latin'],
  pt: ['Latin'],
  ja: ['Han', 'Hiragana', 'Katakana'],
  ko: ['Hangul'],
  'zh-CN': ['Han'],
  ar: ['Arabic'],
  hi: ['Devanagari'],
  te: ['Telugu'],
  ta: ['Tamil'],
  kn: ['Kannada'],
  ml: ['Malayalam'],
  bn: ['Bengali'],
  mr: ['Devanagari'],
  nl: ['Latin'],
  ru: ['Cyrillic'],
};

function getLetterCharacters(value) {
  return [...String(value)].filter((character) => /\p{L}/u.test(character));
}

function getCharacterScript(character) {
  return Object.entries(scriptPatterns).find(([, pattern]) => pattern.test(character))?.[0] || '';
}

export function normalizeForComparison(value) {
  return String(value)
    .normalize('NFKC')
    .toLocaleLowerCase()
    .replace(/[^\p{L}\p{M}\p{N}]+/gu, '');
}

export function isSingleWord(value) {
  return /^[\p{L}\p{M}\p{N}]+$/u.test(String(value).trim());
}

export function isTargetLanguageText(value, targetCode) {
  const expectedScripts = targetScriptGroups[targetCode];
  if (!expectedScripts) return false;

  const letters = getLetterCharacters(value);
  if (!letters.length) return false;

  const hasExpectedScript = letters.some((character) =>
    expectedScripts.includes(getCharacterScript(character)),
  );
  if (!hasExpectedScript) return false;

  const allowedScripts = new Set(expectedScripts);
  if (!expectedScripts.includes('Latin')) {
    allowedScripts.add('Latin');
  }

  return letters.every((character) => {
    const script = getCharacterScript(character);
    return !script || allowedScripts.has(script);
  });
}

function getNumericValue(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function isUsableTranslation(value, inputText, targetCode, maxLength) {
  return (
    typeof value === 'string' &&
    value.trim() &&
    value.length <= maxLength &&
    isTargetLanguageText(value, targetCode)
  );
}

function collectExactMatchCandidates(result, inputText, targetCode, maxLength) {
  if (!Array.isArray(result.matches)) return [];

  const normalizedInput = normalizeForComparison(inputText);
  return result.matches
    .filter((match) => {
      return (
        match &&
        typeof match.translation === 'string' &&
        typeof match.segment === 'string' &&
        normalizeForComparison(match.segment) === normalizedInput &&
        isUsableTranslation(match.translation, inputText, targetCode, maxLength)
      );
    })
    .map((match) => ({
      source: 'matches',
      translation: match.translation,
      matchScore: getNumericValue(match.match),
      quality: getNumericValue(match.quality),
    }));
}

function getDistinctTranslations(candidates) {
  const seen = new Set();
  return candidates.filter((candidate) => {
    const normalized = normalizeForComparison(candidate.translation);
    if (seen.has(normalized)) return false;
    seen.add(normalized);
    return true;
  });
}

export function selectReliableTranslation(
  result,
  { inputText, sourceCode, targetCode, maxLength = 5000 },
) {
  if (!result || typeof result !== 'object') return null;

  const responseTranslation = result.responseData?.translatedText;
  const responseCandidate = isUsableTranslation(
    responseTranslation,
    inputText,
    targetCode,
    maxLength,
  )
    ? {
        source: 'responseData',
        translation: responseTranslation,
        matchScore: getNumericValue(result.responseData?.match),
        quality: Number.POSITIVE_INFINITY,
      }
    : null;

  const matchCandidates = collectExactMatchCandidates(
    result,
    inputText,
    targetCode,
    maxLength,
  ).sort((left, right) => {
    if (right.matchScore !== left.matchScore) {
      return right.matchScore - left.matchScore;
    }
    return right.quality - left.quality;
  });

  const selected = responseCandidate || matchCandidates[0];
  if (!selected) return null;

  const candidates = getDistinctTranslations(
    [responseCandidate, ...matchCandidates].filter(Boolean),
  );
  const warnings = [];

  if (!responseCandidate && typeof responseTranslation === 'string' && responseTranslation.trim()) {
    warnings.push(
      'The service returned mixed language results, so a language-matched result was selected.',
    );
  }

  if (isSingleWord(inputText) && candidates.length > 1) {
    warnings.push(
      'This single word may have more than one meaning. Add a short phrase for a more reliable translation.',
    );
  }

  return {
    text: selected.translation,
    warning: warnings.join(' '),
    source: selected.source,
    sourceCode,
    targetCode,
  };
}